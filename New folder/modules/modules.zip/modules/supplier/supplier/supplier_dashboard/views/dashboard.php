
<!--************************************
		Banner End
*************************************-->
<!--************************************
		Main Start
*************************************-->
<!-----------bhagya---------------------->
<main id="tg-main" class="tg-main tg-haslayout">

	<section class="tg-main-section tg-haslayout">
		<div class="container">

        
			<div class="col-sm-12 col-xs-12 pull-right">
				<div class="row">
					<div class="tg-tickets">
                        <div class="col-md-4">  
						    <div class="tg-ticket">
                            
							    <div class="tg-matchdetail">
                                    <span class="tg-theme-tag">Total Suppliers : 1860</span>
                                    <h4>Sample Name 1</h4></h4>
                                    <ul class="tg-matchmetadata">
                                        <li><address> Short DIscription</address></li>
                                    </ul>
                                </div>
                            </div>
							
                        </div>
                        <div class="col-md-4">
                            <div class="tg-ticket">
                                <div class="tg-matchdetail">
                                    <span class="tg-theme-tag">Total Suppliers : 1862</span>
                                    <h4>Sample Name 2</h4></h4>
                                    <ul class="tg-matchmetadata">
                                        <li><address> Short DIscription</address></li>
                                    </ul>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tg-ticket">
                                <div class="tg-matchdetail">
                                    <span class="tg-theme-tag">Total Suppliers : 1889</span>
                                    <h4>Sample Name 3</h4></h4>
                                    <ul class="tg-matchmetadata">
                                        <li><address> Short DIscription</address></li>
                                    </ul>
                                </div>
                                
                            </div>
                        </div>


					</div>
				</div>
            </div>
            
        </div>  
        <div class="container">  
            <div class="col-sm-12 col-xs-12 col-md-12 pull-right" style="margin-top:80px">
				<div class="row">
					<div class="tg-tickets">
                        <div class="col-md-4">  
						    <div class="tg-ticket">
                            
							    <div class="tg-matchdetail">
                                    <span class="tg-theme-tag">Total Suppliers : 1860</span>
                                    <h4>Sample Name 1</h4></h4>
                                    <ul class="tg-matchmetadata">
                                        <li><address> Short DIscription</address></li>
                                    </ul>
                                </div>
                            </div>
							
                        </div>
                        <div class="col-md-4">
                            <div class="tg-ticket">
                                <div class="tg-matchdetail">
                                    <span class="tg-theme-tag">Total Suppliers : 1862</span>
                                    <h4>Sample Name 2</h4></h4>
                                    <ul class="tg-matchmetadata">
                                        <li><address> Short DIscription</address></li>
                                    </ul>
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="tg-ticket">
                                <div class="tg-matchdetail">
                                    <span class="tg-theme-tag">Total Suppliers : 1889</span>
                                    <h4>Sample Name 3</h4></h4>
                                    <ul class="tg-matchmetadata">
                                        <li><address> Short DIscription</address></li>
                                    </ul>
                                </div>
                                
                            </div>
                        </div>


					</div>
				</div>
			</div>
		</div>
	</section>
</main>
