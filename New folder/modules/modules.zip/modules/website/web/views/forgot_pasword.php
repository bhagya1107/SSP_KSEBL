
<!-- loader backdrop -->

<!-- Page container -->
<div class="gx-container">

  
    <!-- Main Container -->
    <div class="gx-main-container">

     
        <!-- Main Content -->
        <div class="gx-main-content">
             <!--gx-wrapper-->
            <div class="gx-wrapper">
                <div class="login-container d-flex justify-content-center align-items-center animated slideInUpTiny animation-duration-3">
                    <div class="login-content">
                        <div class="login-header" style="text-align:center">
                           
                        </div>
                        <div class="login-form">
                               
                                <fieldset   style="width: 325px;margin-left: 453px; margin-top: 93px;">
								<h3>Forgot Password</h3>
                                    <label>Enter your Registered Mobile No</label>
                                    <div class="form-group" id="email_group">
                                        <input name="email" id="phoneno" class="form-control form-control-lg" placeholder="PhoneNo" type="email">
                                    </div><br>
                                    
                                    <div style="color: red;"><span> </span></div>
                         
                                    <button type="submit" class="gx-btn gx-btn-rounded gx-btn-primary" id="submit">Submit</button>
<!--                                    <span style="float:right;"><a href="<?php echo site_url('/');?>" title="Login">Login</a></span>
                      -->
                                </fieldset>
                        </div>
                    </div>
                </div>
            </div>
            <!--/gx-wrapper-->

            <!-- Footer -->
            <footer class="gx-footer">
                <div class="d-flex flex-row justify-content-between">
                     <p style="margin-left:470px;">NETROXE IT SOLUTIONS</p>
                </div>
            </footer>
            <!-- /footer -->

        </div>
        <!-- /main content -->

    </div>
    <!-- /main container -->

</div>
<!-- /page container -->

<!-- Menu Backdrop -->
<div class="menu-backdrop fade"></div>
<!-- /menu backdrop -->

<!--Load JQuery-->


</body>
</html>

