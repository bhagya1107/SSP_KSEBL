</div><br>
<br>
<div style="text-align:center;border-top: 1px solid #e9e9e9;background: #8fd1ff87;" align="center">
	<div style="font-size: 10px;color: #64808e;padding: 8px;">© ALL RIGHTS RESERVED | 
	<a style="color:#36a2eb" href="www.citymedshop.com" target="_blank">CITYMEDSHOP</a> </div>
</div>

</div>

</div>
<!-- </body>
</html> -->