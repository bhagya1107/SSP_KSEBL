<?php
class Settings_model extends CI_Model
{

  

}

 ?>
