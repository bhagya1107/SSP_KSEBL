<?php
class User_management_model extends CI_Model
{

  public function getUserProfile()
  {
     $this->db->select('*');
     $this->db->where('active_status',0);
     return $this->db->get("suppliers")->result();
  }
  public function activate_account($table,$id)
  {
   $this->db->where('uid',$id); 
   $this->db->set('active_status',1);
   $this->db->update('suppliers');
  }
  public function ajaxselect($statusType,$userType)
  {
   
     $this->db->select('*');
     $this->db->where('active_status',$statusType);
      $this->db->where('user_type',$userType);
     return $this->db->get("suppliers")->result();
  }
  
}
