<form name="frm" action="" name="frm" id="frm" enctype="multipart/form-data" method="post">
<div class="pcoded-content">
  <div class="pcoded-inner-content">
      <div class="main-body">
          <div class="page-wrapper">
              <div class="page-body">
                <div class="row">


  <div class="col-md-12">

<div class="page-header" >
  <div class="row align-items-end" >
      <div class="col-lg-3">
          <div class="page-header-title">
              <div class="d-inline">
                  <h4>Suppliers</h4>
                  <span>List of registerd suppliers</span>
              </div>
          </div>

      </div>
        <div class="col-lg-3">
          <div class="form-group row form_filter"  >
                 <label class="col-sm-5 col-lg-3">Status</label>
          <div class="col-sm-7 col-lg-9">
                <select class="select2-placeholer form-control" data-placeholder="Select a status" name="status_type" id="status_type"   onchange="filter_datatable(this.value);statustypeid();">
                  <option value="0"   >To Approve</option>
                  <option value="1"  > Approved</option>
                </select>
        </div>
    </div>
      </div>
        <div class="col-lg-3">
           <div class="form-group row form_filter"  >
                 <label class="col-sm-5 col-lg-3" >User&nbsp;Type</label>

          <div class="col-sm-7 col-lg-9" >
                <select style="margin-left: 10px;" class="select2-placeholer form-control" data-placeholder="Select a status" name="status_type" id="status_type"   onchange="filter_datatable(this.value);statustypeid();">
                  <option value="0"   >Both</option>
                  <option value="1"  > Contractors</option>
                  <option value="1"  > Suppliers</option>
                </select>
        </div>
    </div>

      </div>
       
	   <div class="form-group row form_filter"  >
                 <!-- <label class="col-sm-5 col-lg-3">Status</label> -->
				  <div class="col-sm-7 col-lg-9" style="margin-left: 150px;">
                 <a data-toggle="modal" data-target="#importfile"><input type="button" style="background-color: #0e214c"  class="btn  btn-sm btn-out-dashed btn-success btn-square" value="IMPORT FILE" /></a>
				</div>
    </div>
   <!--               <div class="form-group row form_filter"  >
                 <label class="col-sm-5 col-lg-3">User Type</label>
          <div class="col-sm-7 col-lg-9">
                <select class="select2-placeholer form-control" data-placeholder="Select a status" name="status_type" id="status_type"   onchange="filter_datatable(this.value);statustypeid();">
                
                  <option value="0"   >Suppliers</option>
                  <option value="1"  > Contractors</option>
                  <option value="1"  > Both</option>
                </select>
        </div>

              </div> -->
         <!--        <div class="form-group row form_filter" >
                 <label class="col-sm-6 col-lg-3"></label>
          <div class="col-sm-7 col-lg-9" >
               
              <a data-toggle="modal" data-target="#importfile"><input type="button"  class="btn  btn-sm btn-out-dashed btn-success btn-square" value="IMPORT FILE" /></a>
        </div>
              </div> -->

      <div class="col-lg-4" style="margin-left: 700px;">
          <div class="page-header-breadcrumb">
              <ul class="breadcrumb-title">
                  <li class="breadcrumb-item">
                      <a href="<?php echo admin_url();?>dashboard"> <i class="feather icon-home"></i> </a>
                  </li>
                  
                  <li class="breadcrumb-item" ><a href="#!">Suppliers</a>
                  </li>
              </ul>
          </div>
      </div>
  </div>
</div>
  <div class="card borderless-card">

<!-- </div> -->

                        <div class="card">

                            <div class="card-block">
                                <div class="table-responsive dt-responsive">
                                    <table id="dt-ajax-object" class="table table-striped table-bordered nowrap">
                                        <thead>
                                            <tr>
                                              <th>#</th>
                                              <th>Supplier Name</th>
                                              <th>Registered Date</th>
                                              <th>Pan No</th>
                                              <th>Contact Person</th>
                                              <th>Mobile</th>
                                              <th>Email</th>
                                              <th>Status</th>
                                              <th>View Profile</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <td>1</td>
                                            <td>Atandra Energy Pvt. Ltd.</td>
                                            <td>20/08/2020</td>
                                            <td>SSP00001</td>
                                            <td>Rajeev</td>
                                            <td>8887775550</td>
                                            <td>abc@gmail.com</td>
                                            <td>Active</td>
                                            <td>
                                              <a href="<?= admin_url('user_management/supplier_profile') ?>"><input type="button" class="btn  btn-sm btn-out-dashed btn-success btn-square" value="VIEW PROFILE"></a>
                                            </td>
                                          </tr>
                                        </tbody>
                                        <tfoot>
                                          <tr>
                                            <th>#</th>
                                            <th>Supplier Name</th>
                                            <th>Registered Date</th>
                                            <th>Pan No</th>
                                            <th>Contact Person</th>
                                            <th>Mobile</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                            <th>View Profile</th>
                                          </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                      </div>

                </div>
                    <!-- Checkbox Tree card end -->
                    <!-- DATA TABLE -->


                    <!-- DATA TABLE END  -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </form>

    <?php   $this->view('template/admin/dataTable.php');  ?>

<!-- <script>
$( document ).ajaxStart(function() {
	$('#loader').show();
});
$( document ).ajaxStop(function() {
	$('#loader').hide();
});
</script> -->
<script>
table = $('#dt-ajax-object').DataTable({
  });
</script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/files\bower_components\lightbox2\js\lightbox.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/js/myScript.js"></script>


<!-- ------------------------------import file------------------------------- -->


<div class="modal fade" id="importfile" style="padding-left: 0px !important;">

    <div class="modal-dialog">
        <div class="modal-content" style="width:583px;height:200px;">

            <!-- Modal Header -->
            <div class="modal-header">
               
            
<div class="tab-content">
          <form action="" method="POST"><button type="button" class="btn btn-danger" data-dismiss="modal"style="margin-left: 500px;" >X</button>
            <h4 >IMPORT SUPPLIERS LIST</h4>
<table style="margin-top: 40px;" >
  <th></th>
<th><input type="file" name=""></th>
<td></td>
<td> <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button></td>


</table>
</form>
  
 <!--  <div class="modal-footer" >
 
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>  -->       
       </div>
    </div>
</div>
</div>
</div>
               
