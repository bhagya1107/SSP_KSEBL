<?php
class User_management_model extends CI_Model
{

  public function getUserProfile()
  {
     $this->db->select('*');
     $this->db->where('active_status',0);
     return $this->db->get("suppliers")->result();
  }
  
}
